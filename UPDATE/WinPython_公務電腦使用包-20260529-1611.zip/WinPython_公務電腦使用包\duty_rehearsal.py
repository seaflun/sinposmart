﻿# -*- coding: utf-8 -*-
"""
Read-only rehearsal for the TYFD duty management automation.

This script logs in, reads the duty table and related query pages, then prints
the actions that would be created. It never clicks save/submit.
"""

from __future__ import annotations


import argparse
import getpass
import json
import os
import re
import sys
import time
from dataclasses import asdict, dataclass, field
from datetime import date, datetime, timedelta
from typing import Any

from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


BASE_URL = "https://dutymgt.tyfd.gov.tw/tyfd119"

DUTY_TABLE_AP = "wap119.RPS105020"
ENTRY_LOG_AP = "wap119.RPS04040"
WORK_LOG_AP = "wap119.RPS04060"
CASE_QUERY_AP = "wap119.RPS04061"

HANDOFF_HOURS = [8, 10, 12, 14, 16, 18, 20, 22]
OFF_DUTY_SUMMARY_KEYS = {
    "公假",
    "請休",
    "產假",
    "病假",
    "事假",
    "榮譽假",
    "喪假",
    "差假",
    "婚假",
    "特別註記",
    "補休",
    "其他假別",
    "停休",
    "輪休公假",
}
TRAINING_BY_WEEKDAY = {
    0: ("河川抽水及水源運用", "SCBA訓練", "火災特性"),
    1: ("通風排煙訓練", "人命救助訓練", "火場控制及殘火處理"),
    2: ("個人防護裝備操作", "常訓體技能訓練", "救護訓練"),
    3: ("車輛裝備基礎保養維護", "戰術體能訓練", "救護訓練"),
    4: ("救生艇拆裝組合訓練", "船外機與橡皮艇", "個人水域防護裝備介紹"),
    5: ("破壞器材操作", "入室搜救", "五用氣體檢知器及CO探測器"),
    6: ("車輛駕訓", "環境整理", "器材車、化學(處理)車"),
}
TRAINING_REASON = {
    "河川抽水及水源運用": "搶救訓練",
    "通風排煙訓練": "搶救訓練",
    "個人防護裝備操作": "裝備器材保養",
    "車輛裝備基礎保養維護": "裝備器材保養",
    "救生艇拆裝組合訓練": "裝備器材保養",
    "破壞器材操作": "裝備器材保養",
    "車輛駕訓": "搶救訓練",
    "SCBA訓練": "裝備器材保養",
    "人命救助訓練": "搶救訓練",
    "常訓體技能訓練": "體技能訓練",
    "戰術體能訓練": "體技能訓練",
    "船外機與橡皮艇": "裝備器材保養",
    "入室搜救": "搶救訓練",
    "環境整理": "車輛清洗保養",
    "火災特性": "搶救訓練",
    "火場控制及殘火處理": "搶救訓練",
    "救護訓練": "救護訓練",
    "個人水域防護裝備介紹": "裝備器材保養",
    "五用氣體檢知器及CO探測器": "裝備器材保養",
    "器材車、化學(處理)車": "裝備器材保養",
}


# Data models

@dataclass
class DutyRow:
    slot: str
    columns: dict[str, list[str]]


@dataclass
class DutySheet:
    roc_date: str
    unit: str = ""
    rows: list[DutyRow] = field(default_factory=list)
    summary: dict[str, list[str]] = field(default_factory=dict)
    staff: dict[str, dict[str, str]] = field(default_factory=dict)


@dataclass
class CaseRecord:
    report_time: str
    return_time: str
    category: str
    raw: list[str]


@dataclass
class PlannedAction:
    kind: str
    time: str
    actor: str
    target: str
    fields: dict[str, Any]
    source: str
    duplicate_key: str
    date_offset: int = 0


# Date, roster, and radio helpers

def roc_date(d: date) -> str:
    return f"{d.year - 1911:03d}{d.month:02d}{d.day:02d}"


def parse_roc_date(value: str) -> date:
    value = re.sub(r"\D", "", value)
    if len(value) != 7:
        raise ValueError("ROC date must look like 1150517")
    year = int(value[:3]) + 1911
    return date(year, int(value[3:5]), int(value[5:7]))


def nums(text: str) -> list[str]:
    return re.findall(r"\d+", text or "")


def roster_nums(text: str) -> list[str]:
    return nums((text or "").split("合計", 1)[0])


def normalize_num(n: str) -> str:
    return str(int(n)) if str(n).strip().isdigit() else str(n).strip()


def handheld_radio(number: str) -> str:
    n = int(number)
    if 1 <= n <= 5:
        return f"手{n:02d}、{n:02d}-1"
    return f"手{n:02d}"


# Browser navigation helpers

def open_ap(driver: webdriver.Chrome, ap_name: str) -> None:
    url = (
        f"{BASE_URL}/ActionControlServlet?id=00&APname={ap_name}"
        f"&pushButton=load&nextAPname={ap_name}&_txtFirstEntry=TRUE"
    )
    driver.get(url)


def ensure_ap(driver: webdriver.Chrome, ap_name: str) -> bool:
    current_url = driver.current_url or ""
    if f"APname={ap_name}" in current_url or f"nextAPname={ap_name}" in current_url:
        return False
    open_ap(driver, ap_name)
    return True


def js_click(driver: webdriver.Chrome, element_id: str) -> bool:
    return bool(
        driver.execute_script(
            """
            const el = document.getElementById(arguments[0]);
            if (!el) return false;
            el.click();
            return true;
            """,
            element_id,
        )
    )


def js_set(driver: webdriver.Chrome, element_id: str, value: str) -> bool:
    return bool(
        driver.execute_script(
            """
            const el = document.getElementById(arguments[0]);
            if (!el) return false;
            el.value = arguments[1];
            el.dispatchEvent(new Event('change', {bubbles: true}));
            return true;
            """,
            element_id,
            value,
        )
    )


def detect_login_error(driver: webdriver.Chrome) -> str:
    try:
        alert = driver.switch_to.alert
        text = alert.text.strip()
        alert.accept()
        if text:
            return text
    except Exception:
        pass
    return driver.execute_script(
        """
        const text = document.body ? document.body.innerText : '';
        const values = Array.from(document.querySelectorAll('input, textarea, select'))
          .map(el => el.value || el.options?.[el.selectedIndex]?.text || '')
          .join('\\n');
        const pageText = [text, values].join('\\n');
        const known = '帳號密碼有誤或尚未申請帳號權限,請確認後再重新登入';
        if (pageText.includes(known)) return known;
        return '';
        """
    ) or ""


# People picker helpers

def set_people_direct(driver: webdriver.Chrome, people: list[Any]) -> dict[str, Any]:
    """Select form people by writing the same fields as the picker popup.

    Entry-log and work-log insert pages both store selected people in
    ``_hidManId`` and ``_areMan``. Work-log additionally updates ``_txtPcnt``.
    ``people`` can contain names or objects like ``{"id": "...", "name": "..."}``.
    """

    return driver.execute_script(
        """
        const targets = arguments[0].map(item => {
          if (item && typeof item === 'object') {
            return {
              id: String(item.id || item.user_id || '').trim(),
              name: String(item.name || '').trim()
            };
          }
          return {id: '', name: String(item || '').trim()};
        }).filter(x => x.id || x.name);

        function collectPeople() {
          const people = [];
          const seen = new Set();
          function push(id, name, title = '', value = '') {
            id = String(id || '').trim();
            name = String(name || '').trim();
            title = String(title || '').trim();
            value = String(value || '').trim();
            if (!id || !name) return;
            const key = id + ':' + name;
            if (seen.has(key)) return;
            seen.add(key);
            people.push({id, name, title, value});
          }

          const selMan = document.getElementById('_selMan');
          if (selMan) {
            Array.from(selMan.options || []).forEach(opt => {
              const parts = String(opt.value || '').split(',');
              push(parts[0], opt.text, parts[1], opt.value);
            });
          }

          const selManData = document.getElementById('_selManData');
          if (selManData) {
            Array.from(selManData.options || []).forEach(opt => {
              const parts = String(opt.value || '').split(',');
              push(parts[1], opt.text, parts[2], [parts[1], parts[2]].filter(Boolean).join(','));
            });
          }
          return people;
        }

        const available = collectPeople();
        const selected = [];
        const missing = [];
        for (const target of targets) {
          const person = available.find(p =>
            (target.id && p.id === target.id) ||
            (target.name && (p.name === target.name || p.name.includes(target.name) || target.name.includes(p.name)))
          );
          if (person) selected.push({...target, ...person});
          else if (target.id && target.name) selected.push(target);
          else missing.push(target.name || target.id);
        }

        if (missing.length === 0 && selected.length > 0) {
          const ids = selected.map(p => p.id).join(',');
          const names = selected.map(p => p.name).join(',');
          const firstTitle = selected[0]?.title || '';
          const hidManId = document.getElementById('_hidManId');
          const areMan = document.getElementById('_areMan');
          if (hidManId) hidManId.value = ids;
          if (areMan) areMan.value = names;
          const txtMan = document.getElementById('_txtMan');
          if (txtMan) txtMan.value = names;
          const selMan = document.getElementById('_selMan');
          if (selMan) {
            const option = Array.from(selMan.options || []).find(opt =>
              String(opt.value || '').split(',')[0].trim() === selected[0].id ||
              String(opt.text || '').trim() === selected[0].name
            );
            if (option) selMan.value = option.value;
          }
          const selTitle = document.getElementById('_selTitle');
          if (selTitle && firstTitle) selTitle.value = firstTitle;
          const txtTitle = document.getElementById('_txtTitle');
          if (txtTitle && selTitle && selTitle.selectedIndex >= 0) txtTitle.value = selTitle.options[selTitle.selectedIndex].text;
          const pcnt = document.getElementById('_txtPcnt');
          if (pcnt) pcnt.value = String(selected.length);
        }

        return {
          ok: missing.length === 0 && selected.length > 0,
          selected,
          missing,
          hidManId: document.getElementById('_hidManId')?.value || '',
          areMan: document.getElementById('_areMan')?.value || '',
          txtMan: document.getElementById('_txtMan')?.value || '',
          txtTitle: document.getElementById('_txtTitle')?.value || '',
          pcnt: document.getElementById('_txtPcnt')?.value || ''
        };
        """,
        people,
    )


def set_entry_people_direct(driver: webdriver.Chrome, names: list[str]) -> dict[str, Any]:
    return set_people_direct(driver, names)


def select_people_via_popup(driver: webdriver.Chrome, people: list[Any]) -> dict[str, Any]:
    """Select people through the background picker popup."""

    main_window = driver.current_window_handle
    before_handles = set(driver.window_handles)
    WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "_btnOpenWin"))).click()
    WebDriverWait(driver, 10).until(lambda d: len(set(d.window_handles) - before_handles) == 1)
    popup_window = (set(driver.window_handles) - before_handles).pop()
    driver.switch_to.window(popup_window)
    result = driver.execute_script(
        """
        const targets = arguments[0].map(item => {
          if (item && typeof item === 'object') {
            return {
              id: String(item.id || item.user_id || '').trim(),
              name: String(item.name || '').trim(),
              dutyNo: String(item.duty_no || item.dutyNo || item.no || '').trim()
            };
          }
          return {id: '', name: String(item || '').trim(), dutyNo: ''};
        }).filter(x => x.id || x.name || x.dutyNo);
        const checks = Array.from(document.querySelectorAll('input[name="_chkUser"]'));
        const selected = [];
        const missing = [];
        const candidates = checks.map(el => ({
          value: String(el.value || ''),
          rowText: String(el.closest('tr')?.innerText || el.parentElement?.innerText || ''),
          cells: Array.from(el.closest('tr')?.children || []).map(cell => String(cell.innerText || '').trim())
        }));

        for (const target of targets) {
          const box = checks.find(el => {
            const parts = String(el.value || '').split(',');
            const id = parts[0].trim();
            const personName = parts.slice(1).join(',').trim();
            const row = el.closest('tr');
            const rowText = String(row?.innerText || el.parentElement?.innerText || '');
            const cells = Array.from(row?.children || []).map(cell => String(cell.innerText || '').trim());
            return (target.id && id === target.id) ||
                   (target.dutyNo && cells.some(text => text === target.dutyNo)) ||
                   (target.name && personName && (
                     personName === target.name ||
                     personName.includes(target.name) ||
                     target.name.includes(personName) ||
                     rowText.includes(target.name)
                   ));
          });
          if (box) {
            box.scrollIntoView({block: 'center'});
            if (!box.checked) box.click();
            box.dispatchEvent(new Event('change', {bubbles: true}));
            selected.push({
              value: box.value,
              rowText: box.closest('tr')?.innerText || box.parentElement?.innerText || '',
              checked: box.checked
            });
          } else {
            missing.push(target.dutyNo || target.name || target.id);
          }
        }

        return {ok: missing.length === 0 && selected.length > 0, selected, missing, candidates};
        """,
        people,
    )
    if result.get("ok"):
        WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "_btnSure"))).click()
    driver.switch_to.window(main_window)

    try:
        WebDriverWait(driver, 5).until(
            lambda d: d.execute_script(
                """
                return Boolean(
                  document.getElementById('_txtMan')?.value ||
                  document.getElementById('_areMan')?.value ||
                  document.getElementById('_hidManId')?.value
                );
                """
            )
        )
    except TimeoutException:
        pass
    verify = driver.execute_script(
        """
        return {
          hidManId: document.getElementById('_hidManId')?.value || '',
          areMan: document.getElementById('_areMan')?.value || '',
          txtMan: document.getElementById('_txtMan')?.value || '',
          txtTitle: document.getElementById('_txtTitle')?.value || '',
          pcnt: document.getElementById('_txtPcnt')?.value || ''
        };
        """
    )
    result.update(verify)
    result["ok"] = bool(result.get("ok") and ((verify.get("hidManId") and verify.get("areMan")) or verify.get("txtMan")))
    if popup_window in driver.window_handles:
        driver.switch_to.window(popup_window)
        driver.close()
        driver.switch_to.window(main_window)
    return result


def select_entry_people_via_popup(driver: webdriver.Chrome, names: list[str]) -> dict[str, Any]:
    return select_people_via_popup(driver, names)


def set_form_people(driver: webdriver.Chrome, people: list[Any], fallback_popup: bool = True) -> dict[str, Any]:
    """Set selected people without visible browser UI.

    First writes the underlying fields directly. If direct selection cannot
    verify all people and ``fallback_popup`` is true, it uses the same picker
    popup flow the website uses, still inside headless Chrome.
    """

    result = set_people_direct(driver, people)
    if result.get("ok"):
        result["method"] = "direct"
        return result
    if not fallback_popup:
        result["method"] = "direct"
        return result

    popup_result = select_people_via_popup(driver, people)
    popup_result["method"] = "popup"
    return popup_result


def set_entry_people(driver: webdriver.Chrome, names: list[str], fallback_popup: bool = True) -> dict[str, Any]:
    result = select_people_via_popup(driver, names)
    result["method"] = "popup"
    return result


def set_work_people(driver: webdriver.Chrome, people: list[Any], fallback_popup: bool = True) -> dict[str, Any]:
    return set_form_people(driver, people, fallback_popup)


# Form controls and submit helpers

def control_snapshot(driver: webdriver.Chrome) -> list[dict[str, Any]]:
    return driver.execute_script(
        """
        return Array.from(document.querySelectorAll('input, select, textarea, button')).map(el => ({
          tag: el.tagName.toLowerCase(),
          type: el.type || '',
          id: el.id || '',
          name: el.name || '',
          value: el.value || '',
          text: el.innerText || el.options?.[el.selectedIndex]?.text || '',
          options: el.tagName.toLowerCase() === 'select'
            ? Array.from(el.options || []).map(opt => ({value: opt.value, text: opt.text}))
            : []
        }));
        """
    )


def click_insert_control(driver: webdriver.Chrome) -> dict[str, Any]:
    return driver.execute_script(
        """
        const controls = Array.from(document.querySelectorAll('input, button, a'));
        const target = controls.find(el => {
          const text = [el.id, el.name, el.value, el.title, el.innerText]
            .map(x => String(x || '')).join(' ');
          return /新增|加入|Add|Insert|New|Create/i.test(text);
        });
        if (!target) return {ok: false, reason: 'insert control not found'};
        const before = location.href;
        target.click();
        return {
          ok: true,
          id: target.id || '',
          name: target.name || '',
          value: target.value || '',
          text: target.innerText || '',
          before
        };
        """
    )


def click_save_control(driver: webdriver.Chrome) -> dict[str, Any]:
    return driver.execute_script(
        """
        const controls = Array.from(document.querySelectorAll('input, button, a'));
        const target = controls.find(el => {
          const text = [el.id, el.name, el.value, el.title, el.innerText]
            .map(x => String(x || '')).join(' ');
          return /儲存|存檔|確定|送出|Save|Submit/i.test(text);
        });
        if (!target) return {ok: false, reason: 'save control not found'};
        target.click();
        return {
          ok: true,
          id: target.id || '',
          name: target.name || '',
          value: target.value || '',
          text: target.innerText || ''
        };
        """
    )


def click_entry_insert_control(driver: webdriver.Chrome) -> dict[str, Any]:
    return driver.execute_script(
        """
        const target = document.getElementById('_btnInsert');
        if (!target) return {ok: false, reason: 'entry insert control not found'};
        target.click();
        return {
          ok: true,
          id: target.id || '',
          name: target.name || '',
          value: target.value || '',
          text: target.innerText || ''
        };
        """
    )


# Work log automation

def fill_work_log_form_for_test(
    driver: webdriver.Chrome,
    action: dict[str, Any],
    staff: dict[str, dict[str, str]],
    target_roc_date: str,
    save: bool = False,
) -> dict[str, Any]:
    """Fill the work-log form. Save only when explicitly requested."""

    fields = action.get("fields", {})
    time_value = fields.get("工作時間", action.get("time", "00:00"))
    hour, minute = time_value.split(":", 1)
    people = [
        {
            "id": staff.get(str(no), {}).get("user_id", ""),
            "name": staff.get(str(no), {}).get("name", str(no)),
        }
        for no in fields.get("服勤人員", [])
    ]

    navigated = ensure_ap(driver, WORK_LOG_AP)
    if navigated:
        time.sleep(1)
    before_controls = control_snapshot(driver)
    form_ready = driver.execute_script("return Boolean(document.getElementById('_txtDATE') && document.getElementById('_selTIMEH') && document.getElementById('_areDescription'));")
    insert_result = {"ok": True, "skipped": True, "reason": "work form already open"} if form_ready else click_insert_control(driver)
    time.sleep(2)

    fill_result = driver.execute_script(
        """
        const values = arguments[0];
        const result = {set: [], missing: []};
        const used = new Set();

        function visibleControls() {
          return Array.from(document.querySelectorAll('input, select, textarea'));
        }
        function setControl(el, value) {
          if (!el) return false;
          const key = el.id || el.name || `${el.tagName}:${result.set.length}`;
          if (used.has(key)) return false;
          if (el.tagName.toLowerCase() === 'select') {
            const options = Array.from(el.options || []);
            const exactOption = options.find(opt =>
              String(opt.text || '').trim() === String(value).trim() ||
              String(opt.value || '').trim() === String(value).trim()
            );
            const option = exactOption || options.find(opt =>
              String(opt.text || '').includes(String(value).trim())
            );
            if (!option) return false;
            el.value = option.value;
          } else {
            el.value = value;
          }
          el.dispatchEvent(new Event('input', {bubbles: true}));
          el.dispatchEvent(new Event('change', {bubbles: true}));
          used.add(key);
          result.set.push({id: el.id || '', name: el.name || '', value});
          return true;
        }
        function byIds(ids, value) {
          for (const id of ids) {
            const el = document.getElementById(id);
            if (setControl(el, value)) return true;
          }
          return false;
        }
        function byOptionText(value) {
          const el = visibleControls().find(control =>
            control.tagName.toLowerCase() === 'select' &&
            Array.from(control.options || []).some(opt => String(opt.text || '').includes(value))
          );
          return setControl(el, value);
        }
        function byNearbyText(label, value, preferTextarea = false) {
          const normalize = text => String(text || '').replace(/\\s+/g, '');
          const controlsOf = root => Array.from(root.querySelectorAll('input, select, textarea'));
          const rows = Array.from(document.querySelectorAll('tr'));
          for (const row of rows) {
            const cells = Array.from(row.children);
            const labelIndex = cells.findIndex(cell => normalize(cell.innerText).includes(label));
            if (labelIndex < 0) continue;
            const targetCells = cells.slice(labelIndex + 1);
            const controls = targetCells.flatMap(controlsOf);
            const candidates = preferTextarea ? controls.filter(el => el.tagName.toLowerCase() === 'textarea') : controls;
            for (const control of candidates) {
              if (setControl(control, value)) return true;
            }
          }
          const labels = Array.from(document.querySelectorAll('td, th, label, span'));
          const node = labels.find(el => normalize(el.innerText).includes(label));
          if (!node) return false;
          let cursor = node.parentElement;
          for (let depth = 0; depth < 3 && cursor; depth += 1, cursor = cursor.parentElement) {
            const controls = controlsOf(cursor);
            const candidates = preferTextarea ? controls.filter(el => el.tagName.toLowerCase() === 'textarea') : controls;
            for (const control of candidates) {
              if (setControl(control, value)) return true;
            }
          }
          return false;
        }

        if (!byIds(['_txtDATE', '_txtDate', '_txtTaskDate', '_txtSDATE', '_txtSdate'], values.date)) result.missing.push('date');
        if (!byIds(['_selTIMEH', '_selSTIMEH', '_selTimeH', '_selHH', '_selHOUR'], values.hour)) result.missing.push('hour');
        if (!byIds(['_selTIMEM', '_selSTIMEM', '_selTimeM', '_selMM', '_selMIN'], values.minute)) result.missing.push('minute');
        byIds(['_selETIMEH', '_selETimeH'], values.hour);
        byIds(['_selETIMEM', '_selETimeM'], values.minute);
        if (!byOptionText(values.item)) result.missing.push('item');
        if (values.reason && !byNearbyText('事由', values.reason)) result.missing.push('reason');
        return result;
        """,
        {
            "date": target_roc_date,
            "hour": hour,
            "minute": minute,
            "item": fields.get("勤務項目", ""),
            "reason": fields.get("事由", ""),
            "description": fields.get("工作概述", ""),
            "status": fields.get("處理情形", ""),
        },
    )
    time.sleep(1)
    content_result = driver.execute_script(
        """
        const values = arguments[0];
        const result = {set: [], missing: []};
        function setDirect(id, value) {
          const el = document.getElementById(id);
          if (!el) return false;
          el.value = value;
          el.dispatchEvent(new Event('input', {bubbles: true}));
          el.dispatchEvent(new Event('change', {bubbles: true}));
          result.set.push({id: el.id || '', name: el.name || '', value});
          return true;
        }
        if (!setDirect('_areDescription', values.description)) result.missing.push('description');
        if (!setDirect('_areStatus', values.status)) result.missing.push('status');
        return result;
        """,
        {
            "description": fields.get("工作概述", ""),
            "status": fields.get("處理情形", ""),
        },
    )
    fill_result["content"] = content_result

    people_result = set_work_people(driver, people, fallback_popup=True) if people else {"ok": False, "missing": []}
    save_result = click_save_control(driver) if save else {"ok": False, "skipped": True}
    if save:
        time.sleep(2)
    after_controls = control_snapshot(driver)
    return {
        "ok": True,
        "insert": insert_result,
        "fill": fill_result,
        "people": people_result,
        "save": save_result,
        "before_controls": before_controls,
        "after_controls": after_controls,
    }


# Entry log automation

def fill_entry_log_form_for_test(
    driver: webdriver.Chrome,
    action: dict[str, Any],
    staff: dict[str, dict[str, str]],
    target_roc_date: str,
    save: bool = False,
) -> dict[str, Any]:
    """Fill the entry-log form. Save only when explicitly requested."""

    fields = action.get("fields", {})
    time_value = fields.get("系統寫入時間", fields.get("登打時間", action.get("time", "00:00")))
    hour, minute = time_value.split(":", 1)
    target_no = str(action.get("target", ""))
    person = {
        "id": staff.get(target_no, {}).get("user_id", ""),
        "name": staff.get(target_no, {}).get("name", target_no),
        "duty_no": target_no,
    }

    navigated = ensure_ap(driver, ENTRY_LOG_AP)
    if navigated:
        time.sleep(1)
    before_controls = control_snapshot(driver)
    form_ready = driver.execute_script("return Boolean(document.getElementById('_txtDATE') && document.getElementById('_selTIMEH'));")
    insert_result = {"ok": True, "skipped": True, "reason": "entry form already open"} if form_ready else click_insert_control(driver)
    time.sleep(2)

    fill_result = driver.execute_script(
        """
        const values = arguments[0];
        const result = {set: [], missing: []};
        const used = new Set();

        function controls() {
          return Array.from(document.querySelectorAll('input, select, textarea'));
        }
        function setControl(el, value) {
          if (!el) return false;
          const key = el.id || el.name || `${el.tagName}:${result.set.length}`;
          if (used.has(key)) return false;
          if (el.tagName.toLowerCase() === 'select') {
            const option = Array.from(el.options || []).find(opt =>
              String(opt.text || '').trim() === String(value).trim() ||
              String(opt.value || '').trim() === String(value).trim() ||
              String(opt.text || '').includes(String(value).trim())
            );
            if (!option) return false;
            el.value = option.value;
          } else {
            el.value = value;
          }
          el.dispatchEvent(new Event('input', {bubbles: true}));
          el.dispatchEvent(new Event('change', {bubbles: true}));
          used.add(key);
          result.set.push({id: el.id || '', name: el.name || '', value});
          return true;
        }
        function byIds(ids, value) {
          for (const id of ids) {
            if (setControl(document.getElementById(id), value)) return true;
          }
          return false;
        }
        function byOptionText(value) {
          const el = controls().find(control =>
            control.tagName.toLowerCase() === 'select' &&
            Array.from(control.options || []).some(opt => String(opt.text || '').trim() === String(value).trim())
          );
          return setControl(el, value);
        }
        function byNearbyText(label, value) {
          const normalize = text => String(text || '').replace(/\\s+/g, '');
          const rows = Array.from(document.querySelectorAll('tr'));
          for (const row of rows) {
            const cells = Array.from(row.children);
            const labelIndex = cells.findIndex(cell => normalize(cell.innerText).includes(label));
            if (labelIndex < 0) continue;
            const candidates = cells.slice(labelIndex + 1).flatMap(cell =>
              Array.from(cell.querySelectorAll('input, select, textarea'))
            );
            for (const control of candidates) {
              if (setControl(control, value)) return true;
            }
          }
          return false;
        }

        if (!byIds(['_txtDATE', '_txtDate', '_txtTaskDate', '_txtSDATE', '_txtSdate'], values.date)) result.missing.push('date');
        if (!byIds(['_selTIMEH', '_selSTIMEH', '_selTimeH', '_selHH', '_selHOUR'], values.hour)) result.missing.push('hour');
        if (!byIds(['_selTIMEM', '_selSTIMEM', '_selTimeM', '_selMM', '_selMIN'], values.minute)) result.missing.push('minute');
        if (values.duty_item && !byIds(['_selList3'], values.duty_item)) result.missing.push('duty_item');
        if (typeof changeSelList4 === 'function') changeSelList4();
        return result;
        """,
        {
            "date": target_roc_date,
            "hour": hour,
            "minute": minute,
            "duty_item": fields.get("勤務項目", ""),
        },
    )
    time.sleep(1)
    people_result = set_entry_people(driver, [person], fallback_popup=True)
    if not people_result.get("ok"):
        raise RuntimeError("entry people selection failed: " + json.dumps(people_result, ensure_ascii=False))
    selected_people = people_result.get("selected") or []
    selected_person = selected_people[0] or {} if selected_people else {}
    selected_value = str(selected_person.get("value", ""))
    selected_user_id = str(selected_person.get("id", "")).strip() or selected_value.split(",", 1)[0].strip() or people_result.get("hidManId", "")
    selected_title = str(selected_person.get("title", "")).strip()
    selected_man_value = selected_value or ",".join(part for part in (selected_user_id, selected_title) if part)
    outin_result = driver.execute_script(
        """
        const values = arguments[0];
        const result = {set: [], missing: []};
        const used = new Set();

        function controls() {
          return Array.from(document.querySelectorAll('input, select, textarea'));
        }
        function setControl(el, value) {
          if (!el) return false;
          const key = el.id || el.name || `${el.tagName}:${result.set.length}`;
          if (used.has(key)) return false;
          if (el.tagName.toLowerCase() === 'select') {
            const option = Array.from(el.options || []).find(opt =>
              String(opt.text || '').trim() === String(value).trim() ||
              String(opt.value || '').trim() === String(value).trim() ||
              String(opt.text || '').includes(String(value).trim())
            );
            if (!option) return false;
            el.value = option.value;
          } else {
            el.value = value;
          }
          el.dispatchEvent(new Event('input', {bubbles: true}));
          el.dispatchEvent(new Event('change', {bubbles: true}));
          used.add(key);
          result.set.push({id: el.id || '', name: el.name || '', value});
          return true;
        }
        function byIds(ids, value) {
          for (const id of ids) {
            if (setControl(document.getElementById(id), value)) return true;
          }
          return false;
        }
        function byOptionText(value) {
          const el = controls().find(control =>
            control.tagName.toLowerCase() === 'select' &&
            Array.from(control.options || []).some(opt => String(opt.text || '').trim() === String(value).trim())
          );
          return setControl(el, value);
        }
        function byNearbyText(label, value) {
          const normalize = text => String(text || '').replace(/\\s+/g, '');
          const rows = Array.from(document.querySelectorAll('tr'));
          for (const row of rows) {
            const cells = Array.from(row.children);
            const labelIndex = cells.findIndex(cell => normalize(cell.innerText).includes(label));
            if (labelIndex < 0) continue;
            const candidates = cells.slice(labelIndex + 1).flatMap(cell =>
              Array.from(cell.querySelectorAll('input, select, textarea'))
            );
            for (const control of candidates) {
              if (setControl(control, value)) return true;
            }
          }
          return false;
        }

        if (!byIds(['_selMan'], values.man)) result.missing.push('man');
        byIds(['_txtMan'], values.man_name);
        if (values.title) byIds(['_selTitle'], values.title);
        if (values.title_text) byIds(['_txtTitle'], values.title_text);
        if (!byIds(['_selIsout', '_selOutIn', '_selIO', '_selOutin', '_selINOUT'], values.outin_value || values.outin) && !byOptionText(values.outin) && !byNearbyText('出或入', values.outin)) result.missing.push('outin');
        const outinEl = document.getElementById('_selIsout');
        const outinText = outinEl?.options?.[outinEl.selectedIndex]?.text || '';
        if (values.outin_text && outinEl && outinEl.value !== values.outin_value && outinText.trim() !== values.outin_text) result.missing.push('outin_confirm');
        if (values.radio && !byIds(['_txtRadiokind', '_txtRadio', '_txtRadioNo', '_txtWireless'], values.radio) && !byNearbyText('手提無線電編號', values.radio) && !byNearbyText('無線電', values.radio)) result.missing.push('radio');
        if (values.returned && !byIds(['_selReturn', '_selIsReturn', '_txtReturn'], values.returned) && !byOptionText(values.returned) && !byNearbyText('是否歸還', values.returned)) result.missing.push('returned');
        return result;
        """,
        {
            "man": selected_man_value,
            "man_name": person["name"],
            "title": selected_title,
            "title_text": "",
            "outin": fields.get("出或入", ""),
            "outin_text": fields.get("出或入", ""),
            "outin_value": "I3" if fields.get("出或入", "") == "值退" else "",
            "radio": fields.get("手提無線電編號", ""),
            "returned": fields.get("是否歸還", ""),
        },
    )
    time.sleep(1)
    reason_result = driver.execute_script(
        """
        const values = arguments[0];
        const result = {set: [], missing: []};

        function setControl(el, value) {
          if (!el) return false;
          el.value = value;
          el.dispatchEvent(new Event('input', {bubbles: true}));
          el.dispatchEvent(new Event('change', {bubbles: true}));
          result.set.push({id: el.id || '', name: el.name || '', value});
          return true;
        }
        function byIds(ids, value) {
          for (const id of ids) {
            if (setControl(document.getElementById(id), value)) return true;
          }
          return false;
        }
        function byNearbyText(label, value) {
          const normalize = text => String(text || '').replace(/\\s+/g, '');
          const rows = Array.from(document.querySelectorAll('tr'));
          for (const row of rows) {
            const cells = Array.from(row.children);
            const labelIndex = cells.findIndex(cell => normalize(cell.innerText).includes(label));
            if (labelIndex < 0) continue;
            const candidates = cells.slice(labelIndex + 1).flatMap(cell =>
              Array.from(cell.querySelectorAll('input, textarea'))
            );
            for (const control of candidates) {
              if (setControl(control, value)) return true;
            }
          }
          return false;
        }

        if (values.reason && !byIds(['_areMemo', '_txtPlace', '_txtReason', '_txtMemo', '_txtRemark'], values.reason) && !byNearbyText('領用事由及地點', values.reason) && !byNearbyText('事由及地點', values.reason)) {
          result.missing.push('reason');
        }
        return result;
        """,
        {
            "reason": fields.get("領用事由及地點", ""),
        },
    )
    time.sleep(1)

    save_result = click_entry_insert_control(driver) if save else {"ok": False, "skipped": True}
    if save:
        time.sleep(2)
    after_controls = control_snapshot(driver)
    return {
        "ok": True,
        "insert": insert_result,
        "fill": fill_result,
        "outin": outin_result,
        "reason": reason_result,
        "people": people_result,
        "save": save_result,
        "before_controls": before_controls,
        "after_controls": after_controls,
    }


# Manual inspection tools

def open_entry_log_form_for_manual(driver: webdriver.Chrome) -> dict[str, Any]:
    """Open a blank entry-log insert form for manual field inspection."""

    open_ap(driver, ENTRY_LOG_AP)
    time.sleep(1)
    before_controls = control_snapshot(driver)
    form_ready = driver.execute_script("return Boolean(document.getElementById('_txtDATE') && document.getElementById('_selTIMEH'));")
    insert_result = {"ok": True, "skipped": True, "reason": "entry form already open"} if form_ready else click_insert_control(driver)
    time.sleep(2)
    after_controls = control_snapshot(driver)
    return {
        "ok": True,
        "insert": insert_result,
        "before_controls": before_controls,
        "after_controls": after_controls,
        "save": {"ok": False, "skipped": True},
    }


def inspect_entry_log_format(
    driver: webdriver.Chrome,
    action: dict[str, Any],
    staff: dict[str, dict[str, str]],
    target_roc_date: str,
) -> dict[str, Any]:
    """Open entry-log form and capture main/popup control formats."""

    fields = action.get("fields", {})
    time_value = fields.get("系統寫入時間", fields.get("登打時間", action.get("time", "00:00")))
    hour, minute = time_value.split(":", 1)
    target_no = str(action.get("target", ""))
    person = {
        "id": staff.get(target_no, {}).get("user_id", ""),
        "name": staff.get(target_no, {}).get("name", target_no),
        "duty_no": target_no,
    }

    open_ap(driver, ENTRY_LOG_AP)
    time.sleep(1)
    before_controls = control_snapshot(driver)
    form_ready = driver.execute_script("return Boolean(document.getElementById('_txtDATE') && document.getElementById('_selTIMEH'));")
    insert_result = {"ok": True, "skipped": True, "reason": "entry form already open"} if form_ready else click_insert_control(driver)
    time.sleep(2)
    main_before_popup = control_snapshot(driver)
    fill_result = driver.execute_script(
        """
        const values = arguments[0];
        const result = {set: [], missing: []};

        function setById(id, value) {
          const el = document.getElementById(id);
          if (!el) return false;
          if (el.tagName.toLowerCase() === 'select') {
            const option = Array.from(el.options || []).find(opt =>
              String(opt.text || '').trim() === String(value).trim() ||
              String(opt.value || '').trim() === String(value).trim()
            );
            if (!option) return false;
            el.value = option.value;
          } else {
            el.value = value;
          }
          el.dispatchEvent(new Event('input', {bubbles: true}));
          el.dispatchEvent(new Event('change', {bubbles: true}));
          result.set.push({id, value});
          return true;
        }

        if (!setById('_txtDATE', values.date)) result.missing.push('_txtDATE');
        if (!setById('_selTIMEH', values.hour)) result.missing.push('_selTIMEH');
        if (!setById('_selTIMEM', values.minute)) result.missing.push('_selTIMEM');
        if (!setById('_areMemo', values.reason)) result.missing.push('_areMemo');
        return result;
        """,
        {
            "date": target_roc_date,
            "hour": hour,
            "minute": minute,
            "reason": fields.get("領用事由及地點", ""),
        },
    )
    handles_before = set(driver.window_handles)
    WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "_btnOpenWin"))).click()
    WebDriverWait(driver, 10).until(lambda d: len(set(d.window_handles) - handles_before) == 1)
    popup_window = (set(driver.window_handles) - handles_before).pop()
    driver.switch_to.window(popup_window)
    popup_controls = control_snapshot(driver)
    popup_summary = driver.execute_script(
        """
        return {
          title: document.title,
          url: location.href,
          bodyText: document.body ? document.body.innerText.slice(0, 8000) : '',
          checkboxes: Array.from(document.querySelectorAll('input[type="checkbox"], input[name="_chkUser"]')).map(el => ({
            id: el.id || '',
            name: el.name || '',
            value: el.value || '',
            checked: el.checked,
            rowText: el.closest('tr')?.innerText || el.parentElement?.innerText || ''
          })),
          buttons: Array.from(document.querySelectorAll('input, button, a')).map(el => ({
            tag: el.tagName.toLowerCase(),
            type: el.type || '',
            id: el.id || '',
            name: el.name || '',
            value: el.value || '',
            text: el.innerText || ''
          }))
        };
        """
    )
    driver.switch_to.window(driver.window_handles[0])
    return {
        "ok": True,
        "target_person": person,
        "insert": insert_result,
        "fill": fill_result,
        "before_controls": before_controls,
        "main_before_popup": main_before_popup,
        "popup_controls": popup_controls,
        "popup_summary": popup_summary,
        "save": {"ok": False, "skipped": True},
    }


# Login and query readers

def login(driver: webdriver.Chrome, user_id: str, password: str) -> None:
    wait = WebDriverWait(driver, 20)
    driver.get(f"{BASE_URL}/login119")
    wait.until(EC.presence_of_element_located((By.ID, "_txtUsername"))).send_keys(user_id)
    driver.find_element(By.ID, "_txtPassword").send_keys(password)
    driver.execute_script(
        """
        if (document.getElementById('hidFlag')) {
          document.getElementById('hidFlag').value = 'APPLICATION';
        }
        if (typeof Testlogin === 'function') {
          Testlogin();
        } else {
          document.getElementById('ndppc').submit();
        }
        """
    )
    for _ in range(20):
        error = detect_login_error(driver)
        if error:
            raise RuntimeError(error)
        time.sleep(0.25)
    # The legacy app can keep login119 in the address bar after posting. The
    # real proof is whether authenticated AP pages load, so callers verify that.


def query_duty_sheet(driver: webdriver.Chrome, target_roc_date: str) -> DutySheet:
    open_ap(driver, DUTY_TABLE_AP)
    time.sleep(1)
    js_set(driver, "_txtTaskDate", target_roc_date)
    if not js_click(driver, "_btnQuery"):
        js_click(driver, "_btnSearch")
    time.sleep(1.5)
    data = driver.execute_script(
        """
        function cellText(cell) {
          const text = (cell.innerText || '').trim();
          const controls = Array.from(cell.querySelectorAll('textarea,input,select'));
          const hasTextarea = controls.some(el => el.tagName === 'TEXTAREA');
          const visibleControls = controls.filter(el => {
            const style = window.getComputedStyle(el);
            return el.tagName === 'TEXTAREA' || (el.type !== 'hidden' && style.display !== 'none');
          });
          if (text && !hasTextarea) return text;
          const parts = (visibleControls.length ? visibleControls : controls).map(el => {
            if (el.tagName === 'SELECT') return el.options[el.selectedIndex]?.text || el.value || '';
            return el.value || '';
          }).filter(Boolean);
          return parts.length ? parts.join(' ') : text;
        }
        const tables = Array.from(document.querySelectorAll('table'));
        const result = {unit: '', rows: [], summary: {}, staff: {}};
        const bodyText = document.body.innerText || '';
        const unitMatch = bodyText.match(/勤務單位\\s*[:：]\\s*([^\\n\\r\\t ]+)/);
        if (unitMatch) result.unit = unitMatch[1];

        for (const table of tables) {
          const trs = Array.from(table.querySelectorAll('tr'));
          const matrix = trs.map(tr => Array.from(tr.children).map(cellText));
          const flat = matrix.flat().join('|');
          const looksLikeDutyTable = table.className.includes('report_list1') &&
            trs.length >= 20 &&
            matrix.some(row => /^8[~～-]9$/.test((row[0] || '').replace(/\\s+/g, ''))) &&
            matrix.some(row => /^7[~～-]8$/.test((row[0] || '').replace(/\\s+/g, '')));
          if (looksLikeDutyTable) {
            let header = [];
            for (const row of matrix) {
              if ((row[0] || '').includes('時段')) {
                header = row.map((value, index) => {
                  const key = (value || '').replace(/\\s+/g, '');
                  return index === 0 ? '時段' : key;
                });
                break;
              }
            }
            if (!header.length) {
              header = ['時段', '值班', '外勤1', '救護', '備勤', '休息', '檢核欄'];
            }
            for (const row of matrix) {
              if (row.length < 3) continue;
              const slot = row[0].replace(/\\s+/g, '');
              if (!/^\\d{1,2}[~～-]\\d{1,2}$/.test(slot)) continue;
              const cols = {};
              for (let i = 1; i < Math.min(header.length, row.length); i++) {
                const key = (header[i] || '').replace(/\\s+/g, '');
                if (key === '檢核欄') continue;
                if (key) cols[key] = row[i] || '';
              }
              result.rows.push({slot, columns: cols});
            }
          }
          const looksLikeSummary = table.className.includes('report_list1') &&
            trs.length >= 8 &&
            matrix.some(row => /^\\d+(,\\d+)+/.test((row[1] || '').trim()));
          if (looksLikeSummary) {
            const summaryLabels = ['在勤', '輪休', '請休', '外宿', '公假', '產假', '病假', '事假',
              '榮譽假', '喪假', '差假', '婚假', '特別註記', '補休', '其他假別', '停休', '輪休公假'];
            for (const row of matrix) {
              for (let i = 0; i + 1 < row.length; i += 2) {
                const value = row[i + 1] || '';
                if (/^\\d+(,\\d+)*/.test(value.trim())) {
                  const label = summaryLabels.find(key => (row[i] || '').includes(key)) || (Object.keys(result.summary).length ? '未知' : '在勤');
                  result.summary[label] = value;
                }
              }
            }
          }
          const looksLikeStaffTable = table.className.includes('report_list1') &&
            matrix.some(row => row.some(cell => /^1$/.test(cell))) &&
            matrix.flat().join('|').match(/\\d{1,2}\\|[^|]+\\|[^|]+/);
          if (looksLikeStaffTable) {
            for (const row of matrix) {
              for (let i = 0; i + 2 < row.length; i++) {
                const no = (row[i] || '').trim();
                const role = (row[i + 1] || '').trim();
                const name = (row[i + 2] || '').trim();
                if (/^\\d{1,2}$/.test(no) && name) result.staff[no] = {role, name};
              }
            }
          }
        }
        return result;
        """
    )
    sheet = DutySheet(
        roc_date=target_roc_date,
        unit=data.get("unit", ""),
        rows=[
            DutyRow(
                slot=row["slot"],
                columns={key: nums(value) for key, value in row["columns"].items() if key != "檢核欄"},
            )
            for row in data.get("rows", [])
        ],
        summary={key: roster_nums(value) for key, value in data.get("summary", {}).items()},
        staff=data.get("staff", {}),
    )
    off_duty = set()
    for key in OFF_DUTY_SUMMARY_KEYS:
        off_duty.update(sheet.summary.get(key, []))
    if off_duty and "在勤" in sheet.summary:
        sheet.summary["在勤"] = [no for no in sheet.summary["在勤"] if no not in off_duty]
    return sheet


def query_visible_table(driver: webdriver.Chrome, ap_name: str, target_roc_date: str) -> list[list[str]]:
    open_ap(driver, ap_name)
    time.sleep(1)
    for field_id in (
        "_txtSDATE",
        "_txtEDATE",
        "_txtDate",
        "_txtTaskDate",
        "_txtSdate",
        "_txtEDate",
        "_txtSDate",
        "_txtEndDate",
    ):
        js_set(driver, field_id, target_roc_date)
    js_set(driver, "_selSTIMEH", "00")
    js_set(driver, "_selSTIMEM", "00")
    js_set(driver, "_selETIMEH", "23")
    js_set(driver, "_selETIMEM", "59")
    js_set(driver, "_selQDept", "033006")
    js_set(driver, "_selDeptno", "033006")
    js_set(driver, "_txtPageNum", "100")
    for button_id in ("_btnQuery", "_btnSearch"):
        if js_click(driver, button_id):
            break
    time.sleep(1.5)
    raw_rows = driver.execute_script(
        """
        return Array.from(document.querySelectorAll('tr')).map(tr =>
          Array.from(tr.children).map(td => (td.innerText || td.value || '').trim()).filter(Boolean)
        ).filter(row => row.length);
        """
    )
    roc_slash = f"{target_roc_date[:3]}/{target_roc_date[3:5]}/{target_roc_date[5:7]}"
    date_pattern = re.compile(rf"^(?:{re.escape(target_roc_date)}|{re.escape(roc_slash)})\s*\n?\d{{1,2}}:\d{{2}}")

    if ap_name == WORK_LOG_AP:
        return [row for row in raw_rows if len(row) >= 8 and date_pattern.match(str(row[0]))]

    rows: list[list[str]] = []
    index = 0
    while index < len(raw_rows):
        row = raw_rows[index]
        if len(row) >= 6 and date_pattern.match(str(row[0])):
            combined = list(row)
            if index + 1 < len(raw_rows):
                next_row = raw_rows[index + 1]
                if next_row and not date_pattern.match(str(next_row[0])):
                    combined.extend(next_row)
                    index += 1
            rows.append(combined)
        index += 1
    return rows


def query_cases(driver: webdriver.Chrome, target_roc_date: str) -> list[CaseRecord]:
    open_ap(driver, CASE_QUERY_AP)
    time.sleep(1)
    js_set(driver, "_hidDeptno", "033006")
    js_set(driver, "_txtSDATE", target_roc_date)
    js_set(driver, "_txtEDATE", target_roc_date)
    js_set(driver, "_selSTIMEH", "00")
    js_set(driver, "_selSTIMEM", "00")
    js_set(driver, "_selETIMEH", "23")
    js_set(driver, "_selETIMEM", "59")
    js_click(driver, "_btnQuery")
    time.sleep(1.5)
    rows = driver.execute_script(
        """
        return Array.from(document.querySelectorAll('tr')).map(tr =>
          Array.from(tr.children).map(td => (td.innerText || '').trim()).filter(Boolean)
        ).filter(row => row.length >= 3);
        """
    )
    cases: list[CaseRecord] = []
    for row in rows:
        joined = " ".join(row)
        if not re.search(r"\d{1,2}:\d{2}:\d{2}", joined):
            continue
        times = re.findall(r"\d{1,2}:\d{2}:\d{2}", joined)
        category = ""
        for cell in row:
            if "緊急救護" in cell or "火警" in cell:
                category = cell
                break
        cases.append(
            CaseRecord(
                report_time=times[0] if times else "",
                return_time=times[-1] if len(times) > 1 else "",
                category=category,
                raw=row,
            )
        )
    return cases


# Duty table interpretation

def slot_start(slot: str) -> int | None:
    m = re.match(r"(\d{1,2})[~～-](\d{1,2})", slot)
    return int(m.group(1)) if m else None


def slot_end(slot: str) -> int | None:
    m = re.match(r"(\d{1,2})[~～-](\d{1,2})", slot)
    return int(m.group(2)) if m else None


def row_for_hour(sheet: DutySheet, hour: int) -> DutyRow | None:
    for row in sheet.rows:
        start = slot_start(row.slot)
        end = slot_end(row.slot)
        if start is None or end is None:
            continue
        if start <= hour < end:
            return row
    return None


def people_at(sheet: DutySheet, hour: int, column: str) -> list[str]:
    row = row_for_hour(sheet, hour)
    return row.columns.get(column, []) if row else []


def rest_starting_at(sheet: DutySheet, hour: int, next_sheet: DutySheet | None = None) -> dict[str, int]:
    starts: dict[str, int] = {}
    ordered_rows = sorted(sheet.rows, key=lambda item: slot_start(item.slot) if slot_start(item.slot) is not None else -1)
    for row in ordered_rows:
        start = slot_start(row.slot)
        end = slot_end(row.slot)
        if start == hour and end is not None:
            for no in row.columns.get("休息", []):
                block_end = end
                probe = end
                while True:
                    next_row = row_for_hour(sheet, probe)
                    if not next_row or no not in next_row.columns.get("休息", []):
                        break
                    next_end = slot_end(next_row.slot)
                    if next_end is None or next_end <= block_end:
                        break
                    block_end = next_end
                    probe = next_end
                if block_end == 8 and next_sheet and no in people_at(next_sheet, 8, "休息"):
                    probe = 8
                    while True:
                        next_row = row_for_hour(next_sheet, probe)
                        if not next_row or no not in next_row.columns.get("休息", []):
                            break
                        next_end = slot_end(next_row.slot)
                        if next_end is None or next_end <= probe:
                            break
                        block_end = next_end
                        probe = next_end
                starts[no] = block_end
    return starts


def rest_blocks(sheet: DutySheet, next_sheet: DutySheet | None = None) -> list[tuple[str, int, int | None]]:
    blocks: list[tuple[str, int, int | None]] = []
    active: dict[str, int] = {}
    ordered_rows = sorted(sheet.rows, key=lambda item: slot_start(item.slot) if slot_start(item.slot) is not None else -1)
    for row in ordered_rows:
        start = slot_start(row.slot)
        end = slot_end(row.slot)
        if start is None or end is None:
            continue
        current = set(row.columns.get("休息", []))
        for no in current:
            active.setdefault(no, start)
        for no in list(active.keys()):
            if no in current:
                continue
            block_start = active.pop(no)
            block_end = start
            if block_end == 8 and next_sheet and no in people_at(next_sheet, 8, "休息"):
                probe = 8
                while True:
                    next_row = row_for_hour(next_sheet, probe)
                    if not next_row or no not in next_row.columns.get("休息", []):
                        break
                    next_end = slot_end(next_row.slot)
                    if next_end is None or next_end <= probe:
                        break
                    block_end = next_end
                    probe = next_end
            blocks.append((no, block_start, block_end))
    for no, block_start in active.items():
        blocks.append((no, block_start, None))
    return blocks


def external_columns(row: DutyRow) -> dict[str, list[str]]:
    ignore = {"值班", "救護", "備勤", "休息", "檢核欄"}
    return {column: values for column, values in row.columns.items() if column not in ignore}


def has_external_duty(row: DutyRow | None, no: str) -> bool:
    if not row:
        return False
    return any(no in values for values in external_columns(row).values())


def adjacent_rest_start(sheet: DutySheet, no: str, start: int) -> int:
    probe = start - 1
    block_start = start
    while probe >= 0:
        row = row_for_hour(sheet, probe)
        if not row or no not in row.columns.get("休息", []):
            break
        row_start = slot_start(row.slot)
        if row_start is None:
            break
        block_start = row_start
        probe = row_start - 1
    return block_start


def rest_is_external_route(sheet: DutySheet, no: str, start: int, end: int | None) -> bool:
    if start == 8:
        return False
    before = row_for_hour(sheet, start - 1) if start > 0 else None
    after = row_for_hour(sheet, end) if end is not None and end < 24 else None
    return has_external_duty(before, no) or has_external_duty(after, no)


def external_duty_blocks(sheet: DutySheet, next_sheet: DutySheet | None = None) -> list[tuple[str, str, int, int | None, int]]:
    blocks: list[tuple[str, str, int, int | None, int]] = []
    active: dict[tuple[str, str], int] = {}
    ordered_rows = sorted(sheet.rows, key=lambda item: slot_start(item.slot) if slot_start(item.slot) is not None else -1)
    for row in ordered_rows:
        start = slot_start(row.slot)
        end = slot_end(row.slot)
        if start is None or end is None:
            continue
        current: set[tuple[str, str]] = set()
        for column, values in external_columns(row).items():
            for no in values:
                current.add((column, no))
                route_start = adjacent_rest_start(sheet, no, start)
                active.setdefault((column, no), start if route_start == 8 else route_start)
        for key in list(active.keys()):
            if key not in current:
                duty_name, no = key
                if no in row.columns.get("休息", []):
                    continue
                block_start = active.pop(key)
                block_end = start
                if block_end == 8 and next_sheet and no in people_at(next_sheet, 8, duty_name):
                    probe = 8
                    while True:
                        next_row = row_for_hour(next_sheet, probe)
                        if not next_row or no not in next_row.columns.get(duty_name, []):
                            break
                        next_end = slot_end(next_row.slot)
                        if next_end is None or next_end <= probe:
                            break
                        block_end = next_end
                        probe = next_end
                elif block_end == 8 and next_sheet and no not in next_sheet.summary.get("在勤", []):
                    block_end = None
                blocks.append((duty_name, no, block_start, block_end, 0))
        # Extend currently active keys through this row by keeping them in active.
    final_end = slot_end(ordered_rows[-1].slot) if ordered_rows else None
    if final_end is not None:
        for (duty_name, no), start in active.items():
            block_end = final_end
            end_offset = 0
            if final_end == 24 and next_sheet:
                block_end = None
                probe = 0
                while probe < 24:
                    next_row = row_for_hour(next_sheet, probe)
                    if not next_row or no not in next_row.columns.get(duty_name, []):
                        break
                    next_end = slot_end(next_row.slot)
                    if next_end is None or next_end <= probe:
                        break
                    block_end = next_end
                    end_offset = 1
                    probe = next_end
            blocks.append((duty_name, no, start, block_end, end_offset))
    return blocks


def prev_slot_duty(today: DutySheet, yesterday: DutySheet | None, handoff_hour: int) -> list[str]:
    if handoff_hour == 8:
        return people_at(yesterday, 6, "值班") if yesterday else []
    return people_at(today, handoff_hour - 2, "值班")


def case_counts(cases: list[CaseRecord], start_hour: int, end_hour: int) -> dict[str, int]:
    counts = {"救護": 0, "火警": 0}
    for case in cases:
        if not case.report_time:
            continue
        hour = int(case.report_time.split(":")[0])
        if start_hour <= hour < end_hour:
            if "火警" in case.category:
                counts["火警"] += 1
            elif "緊急救護" in case.category:
                counts["救護"] += 1
    return counts


def case_counts_overnight(yesterday_cases: list[CaseRecord], today_cases: list[CaseRecord]) -> dict[str, int]:
    counts = {"救護": 0, "火警": 0}
    for partial in (case_counts(yesterday_cases, 22, 24), case_counts(today_cases, 0, 8)):
        counts["救護"] += partial["救護"]
        counts["火警"] += partial["火警"]
    return counts


def name_of(sheet: DutySheet, number: str) -> str:
    return sheet.staff.get(normalize_num(number), {}).get("name", "")


def sheet_has_duty_data(sheet: DutySheet | None) -> bool:
    if not sheet:
        return False
    if any(values for values in sheet.summary.values()):
        return True
    return any(any(values for values in row.columns.values()) for row in sheet.rows)


def officer_for_training(sheet: DutySheet) -> str:
    on_duty = set(sheet.summary.get("在勤", []))
    for no in ("2", "3", "4", "5"):
        if no in on_duty and name_of(sheet, no):
            return f"小隊長{name_of(sheet, no)}"
    if "1" in on_duty and name_of(sheet, "1"):
        return f"分隊長{name_of(sheet, '1')}"
    return "小隊長OOO"


# Work log text templates

def work_handoff_description() -> str:
    return "\n".join(
        [
            "（一）無線電：良好34支。",
            "（二）消防及救護車【各式消防救災救護車輛】在隊5台、出勤0台、報修1台。",
            "（三）後勤車【機車、幫浦車、指揮車、火場鑑識車】在隊5台、出勤0台、報修0台。",
            "（四）救災器材裝備【橡皮艇、救生艇】在隊2台、出勤0台。",
            "（五）重要記事：（比如○○車輛或橡皮艇報修、防颱應變中心成立等事項）。",
            "（六）TIC：隊上5支。",
        ]
    )


def work_handoff_status(start_hour: int, end_hour: int, counts: dict[str, int]) -> str:
    return work_handoff_status_text(f"{start_hour:02d}-{end_hour:02d}", counts)


def work_handoff_status_text(time_range: str, counts: dict[str, int]) -> str:
    case_parts = []
    if counts["救護"]:
        case_parts.append(f"救護{counts['救護']}件")
    if counts["火警"]:
        case_parts.append(f"火警{counts['火警']}件")
    if case_parts:
        middle = f"二、{'、'.join(case_parts)}"
    else:
        middle = "二、無事故"
    return "\n".join(
        [
            f"一、時間:{time_range}",
            middle,
            "三、無線電車輛交接清楚",
        ]
    )


def radio_test_description() -> str:
    return "11時10分與指揮中心試通無線電基地台訊號良好。"


def radio_test_status() -> str:
    return "\n".join(
        [
            "一、時間 : 11時10分",
            "二、地點 : 新坡分隊",
            "三、內容 : 11時10分與指揮中心試通無線電基地台訊號良好",
        ]
    )


def training_template(topic: str, time_range: str, instructor: str) -> tuple[str, str]:
    description = "\n".join(
        [
            topic,
            f"一、時間：{time_range}",
            "二、地點：分隊駐地",
            f"三、教官：{instructor}",
            f"四、訓練情形：由教官實施{topic}，訓練結果由教官抽測，同仁均熟悉。",
        ]
    )
    status = "訓練結果由教官抽測，同仁均熟悉。"
    if topic == "環境整理":
        description = "\n".join(
            [
                topic,
                f"一、時間：{time_range}",
                "二、地點：分隊駐地",
                f"三、教官：{instructor}",
                "四、訓練情形：由教官分配環境清潔區域，由上班同仁負責打掃整理後，由幹部督導並檢查。",
            ]
        )
        status = "由幹部督導並檢查。"
    elif topic == "車輛駕訓":
        status = "人員均熟悉道路路況及駕駛技能。"
    return description, status


# Actor selection and planned actions

def duty_actor_at(today: DutySheet, yesterday: DutySheet | None, hour: int, minute: int = 0) -> str:
    if hour < 8 and yesterday:
        return (people_at(yesterday, hour, "值班") or [""])[0]
    return (people_at(today, hour, "值班") or [""])[0]


def entry_actor_at(today: DutySheet, yesterday: DutySheet | None, hour: int, minute: int = 0) -> str:
    if minute == 0:
        if hour < 8 and yesterday:
            return (people_at(yesterday, 22, "值班") or people_at(yesterday, hour, "值班") or [""])[0]
        previous = prev_slot_duty(today, yesterday, hour)
        if previous:
            return previous[0]
    return duty_actor_at(today, yesterday, hour, minute)


def next_morning_entry_actor(today: DutySheet, hour: int) -> str:
    return (people_at(today, 22, "值班") or people_at(today, hour, "值班") or [""])[0]


def planned_actions(
    today: DutySheet,
    yesterday: DutySheet | None,
    today_cases: list[CaseRecord],
    target: date,
    yesterday_cases: list[CaseRecord] | None = None,
    tomorrow: DutySheet | None = None,
) -> list[PlannedAction]:
    actions: list[PlannedAction] = []
    yesterday_cases = yesterday_cases or []

    # 08 boundary, including rest-start exceptions.
    today_on = set(today.summary.get("在勤", []))
    yesterday_on = set(yesterday.summary.get("在勤", [])) if yesterday else set()
    today_rest_start_08 = rest_starting_at(today, 8, tomorrow)
    yesterday_rest_start_06 = rest_starting_at(yesterday, 6, today) if yesterday else {}

    for no in sorted(today_on - yesterday_on, key=int):
        if no in today_rest_start_08:
            at = today_rest_start_08[no]
            reason = "到勤"
        else:
            at = 7
            reason = "到勤"
        minute = 0 if no in today_rest_start_08 else 55
        actor = entry_actor_at(today, yesterday, at, minute)
        actions.append(
            PlannedAction(
                kind="entry_log",
                time=f"{at:02d}:{minute:02d}",
                actor=actor,
                target=no,
                fields={
                    "登打時間": f"{at:02d}:{minute:02d}",
                    "系統寫入時間": f"{at:02d}:{minute:02d}",
                    "出或入": "入",
                    "領用事由及地點": reason,
                    "手提無線電編號": handheld_radio(no),
                    "是否歸還": "",
                },
                source="今日在勤且昨日未在勤",
                duplicate_key=f"entry:{target}:{at}{minute:02d}:in:{no}:到勤",
            )
        )

    for no in sorted(yesterday_on - today_on, key=int):
        if no in yesterday_rest_start_06:
            at = 6
            minute = 0
            reason = "休息後退勤"
            actor = entry_actor_at(today, yesterday, at, minute)
        else:
            at = 8
            minute = 0
            reason = "退勤"
            actor = (people_at(yesterday, 22, "值班") or prev_slot_duty(today, yesterday, 8) or [""])[0]
        actions.append(
            PlannedAction(
                kind="entry_log",
                time=f"{at:02d}:00",
                actor=actor,
                target=no,
                fields={
                    "登打時間": f"{at:02d}:00",
                    "系統寫入時間": f"{at:02d}:{minute + 5:02d}" if reason == "退勤" else f"{at:02d}:{minute:02d}",
                    "出或入": "出",
                    "領用事由及地點": reason,
                    "手提無線電編號": handheld_radio(no),
                    "是否歸還": "是",
                },
                source="昨日在勤且今日未在勤",
                duplicate_key=f"entry:{target}:{at}{(minute + 5) if reason == '退勤' else minute:02d}:out:{no}:{reason}",
            )
        )

    for no, start, end in rest_blocks(today, tomorrow):
        if no not in today_on or (start == 8 and no not in yesterday_on):
            continue
        if rest_is_external_route(today, no, start, end):
            continue
        start_offset = 1 if start < 8 else 0
        end_offset = 1 if end is not None and end <= 8 else 0
        if start == 6 and start_offset == 1 and tomorrow and no not in set(tomorrow.summary.get("在勤", [])):
            continue
        start_actor = next_morning_entry_actor(today, start) if start_offset else entry_actor_at(today, yesterday, start, 0)
        actions.append(
            PlannedAction(
                kind="entry_log",
                time=f"{start:02d}:00",
                actor=start_actor,
                target=no,
                fields={
                    "登打時間": f"{start:02d}:00",
                    "系統寫入時間": f"{start:02d}:00",
                    "出或入": "出",
                    "領用事由及地點": "休息",
                    "手提無線電編號": "",
                    "是否歸還": "",
                },
                source="休息簽出",
                duplicate_key=f"entry:{target}:{start}:out:{no}:休息",
                date_offset=start_offset,
            )
        )
        if end is None:
            continue
        if end_offset and start == 6:
            continue
        end_actor = next_morning_entry_actor(today, end) if end_offset else entry_actor_at(today, yesterday, end, 0)
        actions.append(
            PlannedAction(
                kind="entry_log",
                time=f"{end:02d}:00",
                actor=end_actor,
                target=no,
                fields={
                    "登打時間": f"{end:02d}:00",
                    "系統寫入時間": f"{end:02d}:00",
                    "出或入": "入",
                    "領用事由及地點": "休息返隊",
                    "手提無線電編號": "",
                    "是否歸還": "",
                },
                source="休息結束",
                duplicate_key=f"entry:{target}:{end}:in:{no}:休息返隊",
                date_offset=end_offset,
            )
        )

    # External duty sign-out/sign-in. Sign-out at an exact handoff hour is
    # entered by the previous duty desk, same as value handoff records.
    for duty_name, no, start, end, end_offset in external_duty_blocks(today, tomorrow):
        start_offset = 1 if start < 8 else 0
        start_actor = next_morning_entry_actor(today, start) if start_offset else entry_actor_at(today, yesterday, start, 0)
        actions.append(
            PlannedAction(
                kind="entry_log",
                time=f"{start:02d}:00",
                actor=start_actor,
                target=no,
                fields={
                    "登打時間": f"{start:02d}:00",
                    "系統寫入時間": f"{start:02d}:00",
                    "出或入": "出",
                    "領用事由及地點": duty_name,
                    "手提無線電編號": "",
                    "是否歸還": "",
                },
                source="外勤簽出",
                duplicate_key=f"entry:{target}:{start}:out:{no}:{duty_name}",
                date_offset=start_offset,
            )
        )
        if end is None:
            continue
        if end_offset == 0 and end is not None and end <= 8:
            end_offset = 1
        end_actor = next_morning_entry_actor(today, end) if end_offset else duty_actor_at(today, yesterday, max(end - 1, 0), 0)
        actions.append(
            PlannedAction(
                kind="entry_log",
                time=f"{end:02d}:00",
                actor=end_actor,
                target=no,
                fields={
                    "登打時間": f"{end:02d}:00",
                    "系統寫入時間": f"{end:02d}:00",
                    "出或入": "入",
                    "領用事由及地點": "返隊",
                    "手提無線電編號": "",
                    "是否歸還": "",
                },
                source="外勤簽入",
                duplicate_key=f"entry:{target}:{end}:in:{no}:返隊:{duty_name}",
                date_offset=end_offset,
            )
        )

    # Duty handoff entry log and work log.
    for hour in HANDOFF_HOURS:
        outgoing = prev_slot_duty(today, yesterday, hour)
        incoming = people_at(today, hour, "值班")
        actor = outgoing[0] if outgoing else duty_actor_at(today, yesterday, hour)
        if hour == 8:
            time_range = "22-08"
            counts = case_counts_overnight(yesterday_cases, today_cases)
        else:
            start_hour = hour - 2
            time_range = f"{start_hour:02d}-{hour:02d}"
            counts = case_counts(today_cases, start_hour, hour)
        for no in outgoing:
            actions.append(
                PlannedAction(
                    kind="entry_log",
                    time=f"{hour:02d}:00",
                    actor=actor,
                    target=no,
                    fields={
                        "登打時間": f"{hour:02d}:00",
                        "系統寫入時間": f"{hour:02d}:00",
                        "勤務項目": "值班(宿)",
                        "出或入": "值退",
                        "領用事由及地點": "值退",
                        "手提無線電編號": "",
                        "是否歸還": "",
                    },
                    source="值班交接",
                    duplicate_key=f"entry:{target}:{hour}:值退:{no}",
                )
            )
        for no in incoming:
            actions.append(
                PlannedAction(
                    kind="entry_log",
                    time=f"{hour:02d}:00",
                    actor=actor,
                    target=no,
                    fields={
                        "登打時間": f"{hour:02d}:00",
                        "系統寫入時間": f"{hour:02d}:00",
                        "勤務項目": "值班(宿)",
                        "出或入": "值班",
                        "領用事由及地點": "值班",
                        "手提無線電編號": "",
                        "是否歸還": "",
                    },
                    source="值班交接",
                    duplicate_key=f"entry:{target}:{hour}:值班:{no}",
                )
            )
        if actor:
            actions.append(
                PlannedAction(
                    kind="work_log",
                    time=f"{hour:02d}:00",
                    actor=actor,
                    target=actor,
                    fields={
                        "工作時間": f"{hour:02d}:00",
                        "勤務項目": "值班(宿)",
                        "工作概述": work_handoff_description(),
                        "處理情形": work_handoff_status_text(time_range, counts),
                        "服勤人員": [actor],
                    },
                    source="值班交接",
                    duplicate_key=f"work:{target}:{hour}:值班交接:{actor}",
                )
            )

    if sheet_has_duty_data(tomorrow):
        next_target = target + timedelta(days=1)
        next_morning_sources = {"今日在勤且昨日未在勤", "昨日在勤且今日未在勤", "值班交接"}
        for action in planned_actions(tomorrow, today, [], next_target, today_cases, None):
            if action.source not in next_morning_sources:
                continue
            if action.time not in ("06:00", "07:55", "08:00", "08:05"):
                continue
            action.date_offset = 1
            actions.append(action)

    # Radio test at 11:10, entered by 10-12 duty.
    radio_actor = duty_actor_at(today, yesterday, 11, 10)
    if radio_actor:
        actions.append(
            PlannedAction(
                kind="work_log",
                time="11:10",
                actor=radio_actor,
                target=radio_actor,
                fields={
                    "工作時間": "11:10",
                    "勤務項目": "其他",
                    "事由": "無線電試話",
                    "工作概述": radio_test_description(),
                    "處理情形": radio_test_status(),
                    "服勤人員": [radio_actor],
                },
                source="無線電試話",
                duplicate_key=f"work:{target}:1110:無線電試話:{radio_actor}",
            )
        )

    # In-station training records.
    topics = TRAINING_BY_WEEKDAY[target.weekday()]
    training_slots = [
        ("12:00", "09-12", 10, topics[0]),
        ("17:00", "14-17", 16, topics[1]),
        ("21:00", "19-21", 20, topics[2]),
    ]
    instructor = officer_for_training(today)
    for work_time, time_range, actor_hour, topic in training_slots:
        actor = duty_actor_at(today, yesterday, actor_hour)
        end_hour = int(work_time[:2])
        probe_hour = end_hour - 1 if end_hour != 12 else 11
        attendees = set(people_at(today, probe_hour, "救護")) | set(people_at(today, probe_hour, "備勤"))
        attendees -= set(people_at(today, probe_hour, "值班"))
        attendees -= set(people_at(today, probe_hour, "休息"))
        for key in today.rows[0].columns.keys() if today.rows else []:
            if key not in ("值班", "救護", "備勤", "休息", "檢核欄") and key:
                attendees -= set(people_at(today, probe_hour, key))
        description, status = training_template(topic, time_range, instructor)
        if actor:
            actions.append(
                PlannedAction(
                    kind="work_log",
                    time=work_time,
                    actor=actor,
                    target=",".join(sorted(attendees, key=int)),
                    fields={
                        "工作時間": work_time,
                        "勤務項目": "在隊訓練",
                        "事由": TRAINING_REASON.get(topic, ""),
                        "訓練項目": topic,
                        "工作概述": description,
                        "處理情形": status,
                        "服勤人員": sorted(attendees, key=int),
                    },
                    source="在隊訓練",
                    duplicate_key=f"work:{target}:{work_time}:在隊訓練:{topic}",
                )
            )

    def entry_priority(action: PlannedAction) -> int:
        if action.kind != "entry_log":
            return 50
        fields = action.fields
        outin = fields.get("出或入", "")
        reason = fields.get("領用事由及地點", "")
        source = action.source
        if source == "外勤簽入" and outin == "入":
            return 0
        if source == "休息結束" and reason == "休息返隊":
            return 1
        if outin == "值退":
            return 2
        if outin == "值班":
            return 3
        if source == "外勤簽出" and outin == "出":
            return 4
        if source == "休息簽出" and reason == "休息":
            return 5
        return 50

    def sort_key(index_and_action: tuple[int, PlannedAction]) -> tuple[int, int, int]:
        index, action = index_and_action
        hour, minute = [int(part) for part in action.time.split(":")]
        return action.date_offset * 1440 + hour * 60 + minute, entry_priority(action), index

    # Keep insertion order inside the same minute after applying the required
    # entry sequence: 外勤入, 休息入, 值退, 值班, 外勤出, 休息出.
    return [action for _, action in sorted(enumerate(actions), key=sort_key)]


# CLI helpers

def print_summary(today: DutySheet, yesterday: DutySheet | None, cases: list[CaseRecord], actions: list[PlannedAction]) -> None:
    print("\n=== 勤務表讀取 ===")
    print(f"今日: {today.roc_date} 單位={today.unit or '(未讀到)'} 在勤={','.join(today.summary.get('在勤', []))}")
    if yesterday:
        print(f"昨日班: {yesterday.roc_date} 在勤={','.join(yesterday.summary.get('在勤', []))}")
    print(f"表格時段數: 今日 {len(today.rows)} / 昨日 {len(yesterday.rows) if yesterday else 0}")

    print("\n=== 案件查詢 ===")
    print(f"讀到案件 {len(cases)} 件")
    for case in cases[:20]:
        print(f"- {case.report_time} {case.return_time} {case.category}")
    if len(cases) > 20:
        print(f"... 還有 {len(cases) - 20} 件")

    print("\n=== 預演計畫 ===")
    for action in actions:
        if action.kind == "entry_log":
            print(
                f"[出入] 登打{action.fields.get('登打時間', action.time)} "
                f"系統{action.fields.get('系統寫入時間', action.time)} "
                f"登打人={action.actor} 對象={action.target} "
                f"{action.fields.get('出或入')} / {action.fields.get('領用事由及地點')} "
                f"無線電={action.fields.get('手提無線電編號') or '-'} "
                f"歸還={action.fields.get('是否歸還') or '-'} ({action.source})"
            )
        else:
            people = action.fields.get("服勤人員", [])
            print(
                f"[工作] {action.time} 登打={action.actor} 項目={action.fields.get('勤務項目')} "
                f"事由={action.fields.get('事由', '-')} 服勤={','.join(people) if people else '-'} ({action.source})"
            )


def build_driver(headless: bool) -> webdriver.Chrome:
    options = Options()
    if headless:
        options.add_argument("--headless=new")
    options.add_argument("--disable-popup-blocking")
    options.add_argument("--window-size=1280,900")
    return webdriver.Chrome(options=options)


def main() -> int:
    parser = argparse.ArgumentParser(description="Read-only duty automation rehearsal.")
    parser.add_argument("--date", default=roc_date(datetime.now().date()), help="ROC date, e.g. 1150517")
    parser.add_argument("--headless", action="store_true", help="Run Chrome headless.")
    parser.add_argument("--json-out", default="", help="Optional JSON output path.")
    args = parser.parse_args()

    target_date = parse_roc_date(args.date)
    yesterday_date = target_date - timedelta(days=1)
    tomorrow_date = target_date + timedelta(days=1)
    user_id = os.environ.get("DUTY_USER") or input("勤務管理系統帳號: ").strip()
    password = os.environ.get("DUTY_PASSWORD") or getpass.getpass("勤務管理系統密碼: ")

    driver = build_driver(args.headless)
    try:
        login(driver, user_id, password)
        today_sheet = query_duty_sheet(driver, roc_date(target_date))
        yesterday_sheet = query_duty_sheet(driver, roc_date(yesterday_date))
        tomorrow_sheet = query_duty_sheet(driver, roc_date(tomorrow_date))
        yesterday_cases = query_cases(driver, roc_date(yesterday_date))
        cases = query_cases(driver, roc_date(target_date))

        # Query pages are still useful as a smoke test for duplicate-check plumbing.
        work_rows = query_visible_table(driver, WORK_LOG_AP, roc_date(target_date))
        entry_rows = query_visible_table(driver, ENTRY_LOG_AP, roc_date(target_date))

        actions = planned_actions(today_sheet, yesterday_sheet, cases, target_date, yesterday_cases, tomorrow_sheet)
        print_summary(today_sheet, yesterday_sheet, cases, actions)
        print("\n=== 既有紀錄查詢 smoke test ===")
        print(f"工作紀錄簿可見列數: {len(work_rows)}")
        print(f"出入登記簿可見列數: {len(entry_rows)}")
        print("注意: 目前只做讀取與預演，沒有新增或儲存。")

        if args.json_out:
            payload = {
                "target_date": roc_date(target_date),
                "today": asdict(today_sheet),
                "yesterday": asdict(yesterday_sheet),
                "tomorrow": asdict(tomorrow_sheet),
                "cases": [asdict(c) for c in cases],
                "yesterday_cases": [asdict(c) for c in yesterday_cases],
                "actions": [asdict(a) for a in actions],
                "visible_work_rows": work_rows,
                "visible_entry_rows": entry_rows,
            }
            with open(args.json_out, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)
            print(f"JSON 輸出: {args.json_out}")
    finally:
        driver.quit()
    return 0


if __name__ == "__main__":
    sys.exit(main())
